
from flask import *

obj = Flask(__name__)

@obj.route("/")
def f1():
    return '<h1><font color=blue>Welcome to Flask App</font></h1>'

@obj.route("/aboutus")
def f2():
    s='<h2><font color=green>About Us page</font></h2>'
    return s

@obj.route("/mypage/<int:var>")
def f3(var):
    return f'<h2>var value is:{var}</h2>'

@obj.route("/dept/<mydept>")
def f4(mydept):
    if(mydept == 'sales' or mydept == 'qa'):
        return redirect(url_for('f2'))
    else:
        return redirect(url_for('f3',var=100))

if __name__ == '__main__':
    obj.run(debug=True)
