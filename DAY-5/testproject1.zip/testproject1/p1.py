import flask

obj = flask.Flask(__name__)

@obj.route("/")
def f1():
    return '<h1><font color=blue>Welcome to Flask App</font></h1>'

@obj.route("/aboutus")
def f2():
    s='<h2><font color=green>About Us page</font></h2>'
    return s

if __name__ == '__main__':
    obj.run(debug=True)
